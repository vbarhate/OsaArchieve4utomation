#include <stdio.h>
main() {
  printf("Hello world!\n");
}
